package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.tencent.qcloud.core.auth.QCloudCredentialProvider;
import com.tencent.qcloud.core.auth.ShortTimeCredentialProvider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Etity.User;

public class MainActivity extends AppCompatActivity {
    private ImageView pic;
    private TextView app_name;
    private EditText name;
    private EditText pwd;
    private Button submit;
    private Button register;
    private User u ;
    public static String username;
    QCloudCredentialProvider myCredentialProvider = new CosService.MySessionCredentialProvider();
    String secretId = "COS_SECRETID"; //永久密钥 secretId
    String secretKey = "COS_SECRETKEY"; //永久密钥 secretKey

    // keyDuration 为请求中的密钥有效期，单位为秒
    //QCloudCredentialProvider myCredentialProvider =
     //       new ShortTimeCredentialProvider(secretId, secretKey, 300);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pic = findViewById(R.id.picture);
        app_name = (TextView)findViewById(R.id.title);
        name = (EditText)findViewById(R.id.name);
        pwd = (EditText)findViewById(R.id.password);
        submit = (Button) findViewById(R.id.submit);
        register = (Button)findViewById(R.id.register);
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
//                    if(check_connect_net(MainActivity.this)==false){
//                        Toast.makeText(MainActivity.this,"Check your internet connection",Toast.LENGTH_SHORT).show();
//                    }
//                    else{
                        login();
//                    }
                    //justInternet();
                    //Intent intent = new Intent(MainActivity.this,ScreenActivity.class);
                    //startActivity(intent);
                } catch (SQLException e) {
                    e.printStackTrace();
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });
//        if(!check_connect_net(this)){
//            Toast.makeText(MainActivity.this,"Check your internet connection",Toast.LENGTH_SHORT).show();
//        }

        //pic.setImageResource(R.drawable.head);
    }
    public void login() throws SQLException, ClassNotFoundException {
        username = name.getText().toString();//用户输入的用户名和密码
        String password = pwd.getText().toString();
        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(MainActivity.this,"name and password can't be empty",Toast.LENGTH_SHORT).show();
        }
        else{
            Threadcheck thread = new Threadcheck(username,password);
            thread.start();
            //Log.d("msg", "username is" + u.getUser_name()+"--------------------------------------");
            //Log.d("msg", "password is"+u.getUser_pwd()+"--------------------------------------");
                try {
                    thread.join();//测试字符串类型的要用.equals();
                    if( u == null){
                        Toast.makeText(MainActivity.this,"username incorrect or password incorrect",Toast.LENGTH_SHORT).show();
                    }
                    else if(u.getUser_name().equals(username) && u.getUser_pwd().equals(password)){
                        Toast.makeText(MainActivity.this,"Login succeeful",Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(MainActivity.this,ScreenActivity.class);
                        startActivity(intent);
                    }
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this,"Login fail",Toast.LENGTH_SHORT).show();
                }
        }
    }
    /*public void incorrect(){
        String username = name.getText().toString();
        String password = pwd.getText().toString();
    }*/

    class Threadcheck extends Thread{
        String username;
        String password;
        Threadcheck(String n,String p){
            this.username = n;
            this.password = p;
        }
        //检查用户名和密码是否正确
        public void run(){
            //加载驱动
            String DBDRIVER = "com.mysql.jdbc.Driver";
            String DBURL = "jdbc:mysql://cdb-1hqd6ecg.cd.tencentcdb.com:10189/Final_app";
            String DBUSER = "root";
            String DBPASSWORD = "KJT123acms71260";
            //u = new User();
            try {
                Class.forName(DBDRIVER);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            //建立连接
            Connection conn = null;
            try {
                conn = (Connection) DriverManager.getConnection(DBURL,DBUSER,DBPASSWORD);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            PreparedStatement ps = null;
            try {
                ps = conn.prepareStatement("SELECT * FROM User WHERE username = ? and password = ?");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(1,username);//这里的username和数据库里的username进行比较
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(2,password);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ResultSet rs = null;
            try {
                rs = ps.executeQuery();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //找到与数据库里相同的name的user并把它存在数据库里
            try {
                if(rs.next()){
                    u = new User();
                    u.setUser_name(rs.getString("username"));
                    u.setUser_pwd(rs.getString("password"));
                    username = rs.getString("username");
                    //System.out.println("login  okkkk");
                    //System.out.println("success login"+rs.getString(1)+rs.getString(2));
                }
                else{
                    System.out.println("login fails");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if(rs!=null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(ps != null){
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    /**
     * 检查是否能连接网络
     */
    public static boolean check_connect_net(Context con) {
        ConnectivityManager cwjManager = (ConnectivityManager) con
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        try {
            if (cwjManager.getActiveNetworkInfo() != null
                    && cwjManager.getActiveNetworkInfo().isAvailable()) {
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
//    public void justInternet(){
//        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
//
//        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
//
//        if(networkInfo == null || !networkInfo.isAvailable()){
//            //当前有可用网络 
//
//        } else
//        {//当前无可用网络 
//            Toast.makeText(MainActivity.this,"Check your internet connection",Toast.LENGTH_SHORT).show();
//        }
//    }

}