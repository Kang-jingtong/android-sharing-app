package com.example.finalproject;

public interface DataCallBack {
    void getData(String data);
}
