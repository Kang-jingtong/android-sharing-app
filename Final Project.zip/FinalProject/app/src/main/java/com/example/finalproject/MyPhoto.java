package com.example.finalproject;

class MyPhoto {
    /*
照片文件本地路径
*/
    String photoPath;

    /*
照片上传后取得的URL
 */
    String photoUrl;

    /*
照片是否上传成功
 */
    Boolean isUpOk;

    /*
照片标签
 */
    String tag;
}
