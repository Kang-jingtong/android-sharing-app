package com.example.finalproject;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import Etity.Screen;

public class EditActivity extends AppCompatActivity {

    private static final int CAMERA_PERMISSION_APPLY_RESULT = 12341;
    private static final int PHOTO_FROM_CAMERA = 1;
//    private static final String FILE_PATH_KEY = "FILE_PATH";

    private Uri imageURI = null;
    private String fileName = null;

    private Button back;
    private Button post;
    private ImageView photo;
    private EditText editext;
    private Button add_pic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_edit);
        editext = (EditText) findViewById(R.id.edit);
        add_pic = (Button) findViewById(R.id.add_pic);
        add_pic.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                requestCameraPermission();
            }
        });
        back = (Button) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        post = (Button) findViewById(R.id.send);
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadToSQL();
                Intent intent = new Intent(EditActivity.this, ScreenActivity.class);
                //intent.putExtra("name", editext.getText().toString());
                startActivity(intent);
            }
        });
        photo = findViewById(R.id.photo);
    }


    public void loadToSQL(){
        Screen screen = new Screen();
        screen.setText(editext.getText().toString());
        screen.setImage(fileName);
        ThreadUpload thread = new ThreadUpload(screen);
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Toast.makeText(EditActivity.this,"成功存入数据库",Toast.LENGTH_SHORT).show();
    }

    public class ThreadUpload extends Thread{
        Screen s;
        ThreadUpload(Screen s){
            this.s = s;
        }
        MainActivity m = new MainActivity();
        //注册新用户将新用户存入数据库
        public void run(){
            String DBDRIVER = "com.mysql.jdbc.Driver";
            String DBURL = "jdbc:mysql://cdb-1hqd6ecg.cd.tencentcdb.com:10189/Final_app";
            String DBUSER = "root";
            String DBPASSWORD = "KJT123acms71260";
            try {
                Class.forName(DBDRIVER);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            Connection conn = null;
            try {
                conn = (Connection) DriverManager.getConnection(DBURL,DBUSER,DBPASSWORD);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            PreparedStatement ps = null;
            try {
                ps = conn.prepareStatement("INSERT INTO Content (text,picture,time,user_name) VALUES (?,?,?,?)");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(1,s.getText());
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(2,s.getImage());
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(3,getToday("yyyy-MM-dd HH:mm:ss"));
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(4,m.username);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //??????
            int affected = 0;//更新数据
            try {
                affected = ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //Log.d("Thread1" ,"affected:"+affected);
            ///??????
            if(ps != null){
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void requestCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                        != PackageManager.PERMISSION_GRANTED) {
            String[] strings = {Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE};
            requestPermissions(strings, CAMERA_PERMISSION_APPLY_RESULT);
        } else {
            openCamera();
        }
    }

    private void openCamera() {
        int currentapiVersion = android.os.Build.VERSION.SDK_INT;
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        String sdStatus = Environment.getExternalStorageState();
        if (!sdStatus.equals(Environment.MEDIA_MOUNTED)) { //Environment.MEDIA_MOUNTED 代表SDka的状态
            Toast.makeText(this, "无法保存照片!", Toast.LENGTH_SHORT).show();
        } else {
            String cachePath = getExternalCacheDir().getAbsolutePath();
            fileName = getToday("yyyyMMddHHmmss") + ".jpg";
            File tempFile = new File(cachePath);
            if (!tempFile.exists() && !tempFile.isDirectory()) {
                tempFile.mkdirs();
            }
            File targetFile = new File(cachePath + fileName);
            if (currentapiVersion < 24) {
                imageURI = Uri.fromFile(targetFile);
                intent.putExtra(MediaStore.EXTRA_OUTPUT, imageURI);
//                intent.putExtra(FILE_PATH_KEY, targetFile.getAbsolutePath());
            } else {
                try {
                    ContentValues contentValues = new ContentValues(1);
                    contentValues.put(MediaStore.Images.Media.DATA, targetFile.getAbsolutePath());
                    imageURI = this.getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues);
                    intent.putExtra(MediaStore.EXTRA_OUTPUT, imageURI);
                } catch (SecurityException e) {
                    Toast.makeText(this, "未开启存储权限", Toast.LENGTH_SHORT).show();
                }
            }
            if (imageURI != null) {
                startActivityForResult(intent, PHOTO_FROM_CAMERA);
            }
        }
    }
    //you get today's date time and second. We do this save our picture's name. Each picture needs to have an individual name so
    private String getToday(String format) {
        Date today = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
        return simpleDateFormat.format(today);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_CANCELED)
            return;
        if (resultCode == RESULT_OK) {
            // 拍照取得的照片
            if (imageURI == null) {
                return;
            }
            String photoPath = getRealFilePath(this, imageURI);

             //imageURI 刚照的照片
            add_pic.setVisibility(View.GONE);
            photo.setVisibility(View.VISIBLE);
            photo.setImageURI(imageURI);

            CosService cosService = new CosService(this);
            cosService.initCos();
            cosService.upload(photoPath, fileName);
        }
    }

    public static String getRealFilePath(final Context context, final Uri uri) {
        if (null == uri) {
            return null;
        }
        final String scheme = uri.getScheme();
        String data = null;
        if (scheme == null) {
            data = uri.getPath();
        } else if (ContentResolver.SCHEME_FILE.equals(scheme)) {
            data = uri.getPath();
        } else if (ContentResolver.SCHEME_CONTENT.equals(scheme)) {
            Cursor cursor = context.getContentResolver().query(uri, new String[]{MediaStore.Images.ImageColumns.DATA}, null, null, null);
            if (null != cursor) {
                if (cursor.moveToFirst()) {
                    int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
                    if (index > -1) {
                        data = cursor.getString(index);
                    }
                }
                cursor.close();
            }
        }
        return data;
    }
}