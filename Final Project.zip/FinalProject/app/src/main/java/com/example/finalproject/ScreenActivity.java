package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import Adapter.ScreenAdapter;
import Etity.Screen;

public class ScreenActivity extends AppCompatActivity {
    private ListView mLv1;//声明控件
    private List<String> list = new ArrayList<String>();
    private Spinner spinnertext;
    private ArrayAdapter<String> adapter;
    private Button post;
    private Button main_screen;
    private Button user_info;
   // private TextView text2;
    private List<Screen> screenlist = new ArrayList<>();
    //需要在数据源和显示中间增加适配器（桥梁，利用适配器，列表视图可以显示多种不同来源多数据
    public void onCreate(Bundle savedlnstanceState) {
        super.onCreate(savedlnstanceState);
        setContentView(R.layout.activity_screen);
        post = findViewById(R.id.Post);
        post.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScreenActivity.this, EditActivity.class);
                startActivity(intent);
            }
        });

        main_screen = findViewById(R.id.main_screen);
        main_screen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScreenActivity.this, ScreenActivity.class);
                startActivity(intent);
            }
        });
        user_info = findViewById(R.id.user_info);
        user_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ScreenActivity.this, UserInformationActivity.class);
                startActivity(intent);
            }
        });
        spinner();
//        Intent intent1 = getIntent();
//        String text = intent1.getStringExtra("name");
//        text2.setText(text);
        ThreadRead threadRead = new ThreadRead();
        threadRead.start();
        try {
            threadRead.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        //cosService.initCos();

//        RecyclerView recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
//        //GridLayoutManager layoutManager = new GridLayoutManager(this,3);
//        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
//        recyclerView.setLayoutManager(layoutManager);
//        ScreenAdapter adapter = new ScreenAdapter(this,screenlist);
//        recyclerView.setAdapter(adapter);
        mLv1 = (ListView) findViewById(R.id.lv_1);//找到控件
        mLv1.setAdapter(new ScreenAdapter((ScreenActivity.this), screenlist));

    }
    //This is for the spinner button;

    public void spinner(){
        //第一步：定义下拉列表内容
        list.add("Movie");
        list.add("Music");
        list.add("Sports");
        list.add("Education");
        list.add("Others");
        spinnertext = (Spinner) findViewById(R.id.spinner1);
        //第二步：为下拉列表定义一个适配器
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list);
        //第三步：设置下拉列表下拉时的菜单样式
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //第四步：将适配器添加到下拉列表上
        spinnertext.setAdapter(adapter);
        //第五步：添加监听器，为下拉列表设置事件的响应
        spinnertext.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> argO, View argl, int arg2, long arg3) {
                // TODO Auto-generated method stub
                /* 将所选spinnertext的值带入myTextView中*/
                // textview.setText("你的血型是:" + adapter.getItem(arg2));
                /* 将 spinnertext 显示^*/
                argO.setVisibility(View.VISIBLE);
            }

            @Override

            public void onNothingSelected(AdapterView<?> argO) {
                // TODO Auto-generated method stub
                argO.setVisibility(View.VISIBLE);
            }
        });

        //将spinnertext添加到OnTouchListener对内容选项触屏事件处理
        spinnertext.setOnTouchListener(new Spinner.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                // TODO Auto-generated method stub
                // 将mySpinner隐藏
                v.setVisibility(View.INVISIBLE);
                Log.i("spinner", "Spinner Touch事件被触发!");
                return false;
            }
        });

        //焦点改变事件处理
        spinnertext.setOnFocusChangeListener(new Spinner.OnFocusChangeListener() {
            public void onFocusChange(View v, boolean hasFocus) {
                // TODO Auto-generated method stub
                v.setVisibility(View.VISIBLE);
                Log.i("spinner", "Spinner FocusChange事件被触发！");
            }
        });
    }
//    public void initScreen(){
//        Screen apple = new Screen();
//        apple.setText("a");
//        apple.setImage("jpg");
//        apple.setTime("2000-10-11");
//        screenlist.add(apple);
//        //Screen apple1 = new Screen(R.drawable.head,"Vivian","今天！",R.drawable.head,"30 minutes ago",R.drawable.head);
//        //screenlist.add(apple1);
//    }

    class ThreadRead extends Thread{
        //EditActivity e = new EditActivity();
        ThreadRead(){

        }
        //检查用户名和密码是否正确
        public void run(){
            //加载驱动
            String DBDRIVER = "com.mysql.jdbc.Driver";
            String DBURL = "jdbc:mysql://cdb-1hqd6ecg.cd.tencentcdb.com:10189/Final_app";
            String DBUSER = "root";
            String DBPASSWORD = "KJT123acms71260";
            //u = new User();
            try {
                Class.forName(DBDRIVER);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            //建立连接
            Connection conn = null;
            try {
                conn = (Connection) DriverManager.getConnection(DBURL,DBUSER,DBPASSWORD);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            PreparedStatement ps = null;
            try {
                ps = conn.prepareStatement("SELECT text,picture,time,user_name FROM Content ORDER BY content_id DESC");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ResultSet rs = null;
            try {
                rs = ps.executeQuery();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //找到与数据库里相同的name的user并把它存在数据库里
            try {
                while(rs.next()){
                    String text = rs.getString("text");
                    String picture = rs.getString("picture");
                    String time = rs.getString("time");
                    String user_name = rs.getString("user_name");
                   // e.downloadToBucket(picture);
                    CosService cosService = new CosService(ScreenActivity.this);
                    cosService.initCos();
                    //cosService.download(picture);
                    Screen s = new Screen();
                    s.setText(text);
                    s.setImage(picture);
                    s.setTime(time);
                    s.setUser_name(user_name);
                    screenlist.add(s);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if(rs!=null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(ps != null){
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}