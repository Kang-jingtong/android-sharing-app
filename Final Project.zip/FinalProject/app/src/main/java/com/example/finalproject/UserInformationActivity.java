package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import Etity.User;

import static Etity.User.Gender.BOY;
import static Etity.User.Gender.GIRL;

public class UserInformationActivity extends AppCompatActivity {
    private Button modify;
    private TextView username2;
    private TextView gender2;
    private TextView birth2;
    private TextView what_up2;
    private Button main_screen;
    private Button user_info;
    private User u;
    private Button back_to_mainscreen;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_information);
        username2 = (TextView) findViewById(R.id.user_name2);
        gender2 = (TextView) findViewById(R.id.user_gender2);
        birth2 = (TextView) findViewById(R.id.birthday2);
        what_up2 = (TextView) findViewById(R.id.what_up2);
        main_screen = (Button) findViewById(R.id.main_screen);
        back_to_mainscreen = (Button) findViewById(R.id.back_to_mainscreen);
        back_to_mainscreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        main_screen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        modify = (Button) findViewById(R.id.modify);
        modify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(UserInformationActivity.this, ModifyUserInfoActivity.class);
                startActivity(intent);
            }
        });
        user_info = (Button) findViewById(R.id.user_info);
        user_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Intent intent = new Intent(UserInformationActivity.this, UserInformationActivity.class);
//                startActivity(intent);
            }
        });
        Threadprint thread = new Threadprint();
        thread.start();
        try {
            thread.join();
            username2.setText(u.getUser_name());
            //gender2.setText(u.getSex().toString());
            if(u.getSex()==BOY){
                gender2.setText("BOY");
            }
            else if(u.getSex()==GIRL){
                gender2.setText("GIRL");
            }
            else {
                gender2.setText("SECRET");
            }
            birth2.setText(u.getBirth());
            what_up2.setText(u.getWhat_up());
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    class Threadprint extends Thread{
        //检查用户名和密码是否正确
        MainActivity m = new MainActivity();
//        String a = m.username;
        public void run(){
            //加载驱动
            String DBDRIVER = "com.mysql.jdbc.Driver";
            String DBURL = "jdbc:mysql://cdb-1hqd6ecg.cd.tencentcdb.com:10189/Final_app";
            String DBUSER = "root";
            String DBPASSWORD = "KJT123acms71260";
            //u = new User();
            try {
                Class.forName(DBDRIVER);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            //建立连接
            Connection conn = null;
            try {
                conn = (Connection) DriverManager.getConnection(DBURL,DBUSER,DBPASSWORD);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            PreparedStatement ps = null;
            try {
                ps = conn.prepareStatement("SELECT username,sex,birth,what_up from User where username = ? ");
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(1,m.username);//这里的username和数据库里的username进行比较
            } catch (SQLException e) {
                e.printStackTrace();
            }
            ResultSet rs = null;
            try {
                rs = ps.executeQuery();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //找到与数据库里相同的name的user并把它存在数据库里
            try {
                if(rs.next()){
                    u = new User();
                    u.setUser_name(rs.getString("username"));
                    if(rs.getString("sex").equals("BOY")){
                        u.setSex(BOY);
                    }
                    else if(rs.getString("sex").equals("GIRL")){
                        u.setSex(GIRL);
                    }
                    if(rs.getString("birth")!=null){
                        u.setBirth(rs.getString("birth"));
                    }
                    else{
                        u.setBirth(" ");
                    }
                    if(rs.getString("what_up")!=null){
                        u.setWhat_up(rs.getString("what_up"));
                    }

                }
                else{
                    System.out.println("login fails");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            if(rs!=null){
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(ps != null){
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

}