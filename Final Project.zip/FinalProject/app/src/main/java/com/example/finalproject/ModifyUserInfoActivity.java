package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import Etity.User;

import static Etity.User.Gender.BOY;
import static Etity.User.Gender.GIRL;
import static Etity.User.Gender.SECRET;

public class ModifyUserInfoActivity extends AppCompatActivity implements DataCallBack{
    private Button select_birth;
    private RadioGroup group_gender;
    private Button submit;
    private Button back;
    private EditText what_up;
    private User u;
    String bd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_user_info);
        select_birth = (Button) findViewById(R.id.select_birth);
        what_up = (EditText) findViewById(R.id.input_what_up);
        group_gender = (RadioGroup) findViewById(R.id.sex);
        select_birth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BirthSelectDialog dislog = new BirthSelectDialog();
                dislog.show(getSupportFragmentManager(),"aa");
            }
        });
        submit = (Button) findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                u = new User();
//
//                if(group_gender.getCheckedRadioButtonId() == R.id.boy){
//                    u.setSex(User.Gender.BOY);
//                }
//                else if (group_gender.getCheckedRadioButtonId() == R.id.girl){
//                    u.setSex(User.Gender.GIRL);
//                }
//                else if (group_gender.getCheckedRadioButtonId() == R.id.secret){
//                    u.setSex(User.Gender.SECRET);
//                }
//                u.setBirth(bd);
//                u.setWhat_up(what_up.getText().toString());
//                ThreadInsert thread = new ThreadInsert();
//                thread.start();
//                try {
//                    thread.join();
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
                ThreadModify thm = new ThreadModify();
                thm.start();
                try {
                    thm.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                //Log.d("msg", "onClick: "+u.getSex()+u.getBirth()+u.getWhat_up()+"________________--______---------");
                ThreadInsert thread = new ThreadInsert();
                thread.start();
                try {
                    thread.join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                Intent intent = new Intent(ModifyUserInfoActivity.this, UserInformationActivity.class);
                //用于开始到达新的Activity之前移除之前的Activity。这样我们点击back键就会直接回桌面了
                //intent.putExtra("position",position);//记录从哪个界面离开
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);//把上一个activity移除，因为每转换一个屏幕都是打开一个新的界面；
                startActivity(intent);
//                Log.d("msg", "onClick: "+u.getSex()+u.getBirth()+u.getWhat_up()+"________________--______---------");
            }
        });
        back = (Button) findViewById(R.id.back_to_userinfo);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
    //When you select a date you get the numbers on the screen.
    public void getData(String data){
        select_birth.setText(data);
        bd = data;
    }

    class ThreadModify extends Thread{
        public void run(){
            u = new User();

            if(group_gender.getCheckedRadioButtonId() == R.id.boy){
                u.setSex(User.Gender.BOY);
            }
            else if (group_gender.getCheckedRadioButtonId() == R.id.girl){
                u.setSex(User.Gender.GIRL);
            }
            else if (group_gender.getCheckedRadioButtonId() == R.id.secret){
                u.setSex(User.Gender.SECRET);
            }
            u.setBirth(bd);
            u.setWhat_up(what_up.getText().toString());
        }
    }

    class ThreadInsert extends Thread{
       ThreadInsert(){

       }
        MainActivity m = new MainActivity();
        //注册新用户将新用户存入数据库
        public void run(){
            String DBDRIVER = "com.mysql.jdbc.Driver";
            String DBURL = "jdbc:mysql://cdb-1hqd6ecg.cd.tencentcdb.com:10189/Final_app";
            String DBUSER = "root";
            String DBPASSWORD = "KJT123acms71260";
            try {
                Class.forName(DBDRIVER);
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }
            Connection conn = null;
            try {
                conn = (Connection) DriverManager.getConnection(DBURL,DBUSER,DBPASSWORD);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            PreparedStatement ps = null;
            try {
                ps = conn.prepareStatement("UPDATE User SET sex=?,birth=?,what_up=? WHERE username=?");
            } catch (SQLException e) {
                Log.d("msg", "run:------------------------------------------------------------ ");
                e.printStackTrace();
            }
            try {
                if(u.getSex()==User.Gender.BOY){
                    ps.setString(1,"BOY");
                }
                else if(u.getSex()==User.Gender.GIRL){
                    ps.setString(1,"GIRL");
                }
                else if(u.getSex()==User.Gender.SECRET){
                    ps.setString(1,"SECRET");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(2,u.getBirth());
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(3,u.getWhat_up());
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.setString(4,m.username);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            try {
                ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            //??????
            int affected = 0;//更新数据
            try {
                affected = ps.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            Log.d("Thread1" ,"affected:"+affected);
            //??????
            if(ps != null){
                try {
                    ps.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if(conn!=null){
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}