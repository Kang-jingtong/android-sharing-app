package Adapter;

import java.io.File;

public interface DownloadListener {
    void onDownloadSuccess();
}
